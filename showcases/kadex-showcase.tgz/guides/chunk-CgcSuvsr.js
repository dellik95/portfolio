import{o as Ui}from"./chunk-DauwpLFJ.js";import{bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var a={title:`Molecules/Stepper Wizard`,component:Ui,argTypes:{currentStep:{control:{type:`range`,min:0,max:2,step:1}},linear:{control:`boolean`},orientation:{control:`inline-radio`,options:[`horizontal`,`vertical`]},steps:{table:{disable:!0}}},args:{steps:[{id:`details`,label:`Details`,description:`Role & team`},{id:`requirements`,label:`Requirements`,description:`Skills`},{id:`review`,label:`Review`,description:`Confirm`,optional:!0}],currentStep:1,linear:!0,orientation:`horizontal`},render:e=>({props:e,template:`
      <div style="max-width:44rem">
        <kx-stepper-wizard ${o(e)}>
          <div style="padding:1.5rem 0">
            <p style="margin:0">Step body content is projected here for the active step.</p>
          </div>
        </kx-stepper-wizard>
      </div>
    `})};var l={};var s={args:{orientation:`vertical`}};export{l as Playground,s as Vertical,a as default};