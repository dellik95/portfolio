import{b as ut,f as he}from"./chunk-DCAN7EnP.js";import"./chunk-DauwpLFJ.js";import{yt as a}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var d={title:`Organisms/Menu Divider`,component:ut,decorators:[a({imports:[he]})],render:()=>({template:`
      <div
        role="menu"
        style="width:min(100%, 220px); padding:.25rem; border:1px solid var(--kx-color-border, #e5e7eb); border-radius:.5rem; display:flex; flex-direction:column; gap:.125rem"
      >
        <kx-menu-item label="Edit" icon="edit" />
        <kx-menu-item label="Duplicate" icon="copy" />
        <kx-menu-divider />
        <kx-menu-item label="Delete" icon="delete" [danger]="true" />
      </div>
    `})};var m={};export{m as Playground,d as default};