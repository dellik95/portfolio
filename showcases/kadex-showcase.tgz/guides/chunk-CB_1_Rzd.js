import{_ as pt,b as ut,f as he,h as me}from"./chunk-DCAN7EnP.js";import"./chunk-DauwpLFJ.js";import{bt as o,yt as a}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import{$t as ci,Cn as gc,Dr as uc,En as hD,In as jf,Pn as it,an as dv,cn as eD,cr as pI,nt as Qf,x as Ff}from"./chunk-CtdGPoMJ.js";var d=class e{status=it(`open`);onSelect(n){typeof n==`string`&&this.status.set(n)}static ɵfac=function(o){return new(o||e)};static ɵcmp=pI({type:e,selectors:[[`kx-menu-item-demo`]],decls:10,vars:4,consts:[[`menu`,``],[2,`padding`,`3rem`,`display`,`flex`,`justify-content`,`center`],[2,`padding`,`.5rem 1rem`,`border-radius`,`.375rem`,`border`,`1px solid var(--kx-color-border, #d1d5db)`,3,`kxMenuTriggerFor`],[3,`menuItemSelected`,`activeValue`],[`value`,`open`,`label`,`Open`,`accentColor`,`#22c55e`],[`value`,`in-review`,`label`,`In review`,`accentColor`,`#f59e0b`],[`value`,`blocked`,`label`,`Blocked`,`accentColor`,`#ef4444`],[`value`,`archived`,`label`,`Archive`,`icon`,`delete`,3,`danger`]],template:function(o,i){if(o&1&&(ci(0,`div`,1)(1,`button`,2),hD(2),uc(),ci(3,`kx-menu`,3,0),Qf(`menuItemSelected`,function(I){return i.onSelect(I)}),jf(5,`kx-menu-item`,4)(6,`kx-menu-item`,5)(7,`kx-menu-item`,6)(8,`kx-menu-divider`)(9,`kx-menu-item`,7),uc()()),o&2){let c=eD(4);dv(),Ff(`kxMenuTriggerFor`,c),dv(),gc(` Status: `,i.status(),` `),dv(),Ff(`activeValue`,i.status()),dv(6),Ff(`danger`,!0)}},dependencies:[me,he,ut,pt],encapsulation:2})};var N={title:`Organisms/Menu Item`,component:he,argTypes:{label:{control:`text`},icon:{control:`select`,options:[`edit`,`copy`,`delete`,`star`,`download`,`settings`,`flag`,`bookmark`]},iconColor:{control:`text`},description:{control:`text`},shortcut:{control:`text`},accentColor:{control:`text`},danger:{control:`boolean`},disabled:{control:`boolean`},active:{control:`boolean`},value:{table:{disable:!0}},closeOnSelect:{table:{disable:!0}}},args:{label:`Edit`,icon:`edit`,iconColor:null,description:null,shortcut:null,accentColor:null,danger:!1,disabled:!1,active:!1},render:e=>({props:e,template:`
      <div role="menu" style="width:min(100%, 240px); padding:.25rem; border:1px solid var(--kx-color-border, #e5e7eb); border-radius:.5rem">
        <kx-menu-item ${o(e)} />
      </div>
    `})};var j={};var A={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div
        role="menu"
        style="width:min(100%, 240px); padding:.25rem; border:1px solid var(--kx-color-border, #e5e7eb); border-radius:.5rem; display:flex; flex-direction:column; gap:.125rem"
      >
        <kx-menu-item label="Default" icon="edit" />
        <kx-menu-item
          label="With description"
          icon="settings"
          description="Manage workspace preferences"
        />
        <kx-menu-item label="With shortcut" icon="copy" shortcut="\u2318D" />
        <kx-menu-item label="Active" icon="star" [active]="true" />
        <kx-menu-item label="Disabled" icon="download" [disabled]="true" />
        <kx-menu-item label="Danger" icon="delete" [danger]="true" />
      </div>
    `})};var E={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div
        role="menu"
        style="width:min(100%, 240px); padding:.25rem; border:1px solid var(--kx-color-border, #e5e7eb); border-radius:.5rem; display:flex; flex-direction:column; gap:.125rem"
      >
        <kx-menu-item label="Open" accentColor="#22c55e" />
        <kx-menu-item label="In review" accentColor="#f59e0b" />
        <kx-menu-item label="Blocked" accentColor="#ef4444" />
      </div>
    `})};var F={parameters:{controls:{disable:!0}},decorators:[a({imports:[d]})],render:()=>({template:`<kx-menu-item-demo />`})};export{F as InMenu,j as Playground,A as States,E as WithAccentColor,N as default};