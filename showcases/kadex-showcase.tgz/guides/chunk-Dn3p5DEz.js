import{I as _n,bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var n={title:`Atoms/Label`,component:_n,argTypes:{text:{control:`text`},size:{control:`inline-radio`,options:[`sm`,`md`,`lg`]},variant:{control:`select`,options:[`default`,`primary`,`secondary`,`success`,`warning`,`danger`,`info`]},required:{control:`boolean`},for:{control:`text`}},args:{text:`Email address`,size:`md`,variant:`default`,required:!1},render:e=>({props:e,template:`<kx-label ${o(e)} />`})};var s={};var i={args:{required:!0}};var p={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-col gap-1">
        <kx-label text="Default" variant="default" />
        <kx-label text="Primary" variant="primary" />
        <kx-label text="Success" variant="success" />
        <kx-label text="Danger" variant="danger" />
      </div>
    `})};export{s as Playground,i as Required,p as Variants,n as default};