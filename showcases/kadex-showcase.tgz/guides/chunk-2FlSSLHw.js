import{t as A}from"./chunk-BSxDV0VB.js";import"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var t={title:`Dialog/Dialog Footer`,component:A,render:()=>({template:`
      <div style="width:min(100%, 440px); border:1px solid var(--kx-color-border, #e5e7eb); border-radius:.5rem; overflow:hidden">
        <kx-dialog-footer>
          <button style="padding:.5rem 1rem; border-radius:.375rem; border:1px solid var(--kx-color-border, #d1d5db)">
            Cancel
          </button>
          <button style="padding:.5rem 1rem; border-radius:.375rem; border:0; background:var(--kx-color-primary, #4f46e5); color:#fff">
            Save changes
          </button>
        </kx-dialog-footer>
      </div>
    `})};var d={};export{d as Playground,t as default};