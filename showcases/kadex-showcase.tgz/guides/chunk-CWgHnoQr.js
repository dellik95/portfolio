import{m as li}from"./chunk-DauwpLFJ.js";import"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var a={title:`Molecules/Entity Page Layout`,component:li,render:()=>({template:`
      <kx-entity-page-layout>
        <div kxEntityLayoutMain style="padding:1.5rem; border:1px solid var(--kx-color-border-subtle, #e5e7eb); border-radius:.5rem">
          <h2 style="margin:0 0 .5rem; font-weight:600">Main content</h2>
          <p style="margin:0; opacity:.75">Primary details, tabs, and forms live in the main column.</p>
        </div>
        <aside kxEntityLayoutSidebar style="padding:1.5rem; border:1px solid var(--kx-color-border-subtle, #e5e7eb); border-radius:.5rem">
          <h3 style="margin:0 0 .5rem; font-weight:600">Sidebar</h3>
          <p style="margin:0; opacity:.75">Metadata, status, and quick actions.</p>
        </aside>
      </kx-entity-page-layout>
    `})};var r={};export{r as Playground,a as default};