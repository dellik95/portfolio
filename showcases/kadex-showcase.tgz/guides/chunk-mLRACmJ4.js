import{M as Wt,bt as o,rt as we,yt as a}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var i={title:`Atoms/Button Group`,component:Wt,decorators:[a({imports:[we]})],argTypes:{variant:{control:`inline-radio`,options:[`default`,`primary`,`danger`]},size:{control:`inline-radio`,options:[`sm`,`md`,`lg`]},vertical:{control:`boolean`}},args:{variant:`default`,size:`md`,vertical:!1},render:t=>({props:t,template:`
      <kx-button-group ${o(t)}>
        <kx-button>Day</kx-button>
        <kx-button>Week</kx-button>
        <kx-button>Month</kx-button>
      </kx-button-group>
    `})};var l={};var m={args:{vertical:!0}};export{l as Playground,m as Vertical,i as default};