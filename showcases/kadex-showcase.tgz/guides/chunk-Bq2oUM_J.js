import{bt as o,f as Ht}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import{Gr as m,Kr as n,Wr as l}from"./chunk-CtdGPoMJ.js";var c={title:`Atoms/Badge`,component:Ht,argTypes:{variant:{control:`select`,options:[`default`,`primary`,`success`,`warning`,`danger`,`info`]},size:{control:`inline-radio`,options:[`sm`,`md`,`lg`]},dot:{control:`boolean`},removable:{control:`boolean`},content:{control:`text`,description:`Projected badge content`},removed:{table:{disable:!0}}},args:{variant:`primary`,size:`md`,dot:!1,removable:!1,content:`Badge`},render:g=>{var t=g,{content:s}=t,e=n(t,[`content`]);return{props:m(l({},e),{content:s}),template:`<kx-badge ${o(e)}>{{ content }}</kx-badge>`}}};var p={};var b={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap items-center gap-2">
        <kx-badge variant="default">Default</kx-badge>
        <kx-badge variant="primary">Primary</kx-badge>
        <kx-badge variant="success">Success</kx-badge>
        <kx-badge variant="warning">Warning</kx-badge>
        <kx-badge variant="danger">Danger</kx-badge>
        <kx-badge variant="info">Info</kx-badge>
      </div>
    `})};var x={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap items-center gap-2">
        <kx-badge size="sm">Small</kx-badge>
        <kx-badge size="md">Medium</kx-badge>
        <kx-badge size="lg">Large</kx-badge>
      </div>
    `})};var k={args:{dot:!0,content:`Online`}};var y={args:{removable:!0,content:`Dismiss me`}};export{p as Playground,y as Removable,x as Sizes,b as Variants,k as WithDot,c as default};