import{bt as o,dt as M,ft as r}from"./main-5T27SPP5.js";import"./chunk-CtdGPoMJ.js";var s={title:`Icons/Icon`,component:r,argTypes:{name:{control:`text`},size:{control:`inline-radio`,options:[`xs`,`sm`,`md`,`lg`,`xl`]},color:{control:`select`,options:[`current`,`primary`,`secondary`,`success`,`warning`,`danger`,`info`,`gray`]},strokeWidth:{control:{type:`number`,min:.5,max:3,step:.25}},ariaLabel:{control:`text`}},args:{name:`search`,size:`md`,color:`current`,strokeWidth:1.5,ariaLabel:null},render:e=>({props:e,template:`<kx-icon ${o(e)} />`})};var p={};var i={args:{name:`bell`,size:`xl`,color:`primary`}};var c={args:{name:`delete`,size:`lg`,color:`danger`}};var m={parameters:{controls:{disable:!0},layout:`padded`},render:()=>({props:{iconNames:Object.keys(M).sort()},template:`
      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(96px, 1fr)); gap: 12px;">
        @for (name of iconNames; track name) {
          <div style="display: flex; flex-direction: column; align-items: center; gap: 8px; border: 1px solid var(--color-border, #e5e7eb); border-radius: 8px; padding: 12px; text-align: center;">
            <kx-icon [name]="name" size="lg" />
            <span style="font-size: 11px; color: var(--color-text-muted, #6b7280); overflow-wrap: anywhere;">{{ name }}</span>
          </div>
        }
      </div>
    `})};export{m as AllIcons,c as Danger,i as Large,p as Playground,s as default};