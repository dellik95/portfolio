# Getting Started

From an empty Angular&nbsp;22 app to a rendered Kadex UI component. No prior knowledge of the
design system is assumed.

**Prerequisites:** Node&nbsp;20+, an Angular&nbsp;22 app (`ng new my-app`), and a GitHub personal
access token with the `read:packages` scope.

## 1. Point npm at the registry

The public `@dellik95/kadex-ui` package is available on GitHub Packages. npm downloads require authentication. Add an `.npmrc` (project
root or `~/.npmrc`):

```
@dellik95:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

Export the token in your shell (`GITHUB_TOKEN=…`) so the placeholder resolves. CI reads the
same variable.

## 2. Install

```bash
npm i @dellik95/kadex-ui @dellik95/kadex-ui/tokens
```

`@dellik95/kadex-ui/tokens` is a peer of `@dellik95/kadex-ui` — the components need the token
stylesheet to render correctly. Charts (`@dellik95/kadex-ui/charts`) and the rich-text editor
(`@dellik95/kadex-ui/editor`) are separate secondary entry points — import them only when used.

## 3. Load the styles

The components are unstyled until you load the design tokens. Quickest path — you do **not** run
Tailwind: import the prebuilt, fully-materialized stylesheet.

```css
/* src/styles.css */
@import "@dellik95/kadex-ui/tokens/prebuilt/kadex.css";
```

This styles the `@dellik95/kadex-ui` components with no build step. See **Theming** for the Tailwind
(Option&nbsp;A) alternative — pick one, never both.

## 4. Render a component

`@dellik95/kadex-ui` components are standalone — import the component class from its entry point and
list it in a standalone component's `imports`:

```ts
// src/app/app.component.ts
import { Component } from "@angular/core";
import { KxButtonComponent } from "@dellik95/kadex-ui/atoms";

@Component({
  selector: "app-root",
  standalone: true,
  imports: [KxButtonComponent],
  template: `
    <kx-button variant="primary" (clicked)="onSave()">Save</kx-button>
    <kx-button variant="danger" [loading]="deleting" (clicked)="onDelete()">Delete</kx-button>
  `,
})
export class AppComponent {
  deleting = false;
  onSave() {}
  onDelete() {}
}
```

`ng serve` — the buttons render with the design-system styling.

Import from the entry point, never from a deep path inside it — the `@dellik95/eslint-plugin-kadex`
`no-internal-imports` rule enforces this.

## 5. Icons (optional)

`kx-icon` ships **no** icons of its own, so an app only bundles the icon data it registers. Opt in
to the full built-in set (Heroicons outline) once at app config:

```ts
// src/app/app.config.ts
import { ApplicationConfig } from "@angular/core";
import { provideKxDefaultIcons } from "@dellik95/kadex-ui/icons";

export const appConfig: ApplicationConfig = {
  providers: [provideKxDefaultIcons()],
};
```

```ts
import { KxIconComponent } from "@dellik95/kadex-ui/icons";
// template: <kx-icon name="user" size="lg" color="primary" />
```

An unregistered name renders nothing (and logs a one-time warning in dev mode). Apps that supply
their own set can skip `provideKxDefaultIcons()` — the 116-icon default is then dropped from the
bundle entirely.

To add your own icons (name → SVG path), register them alongside it; later registrations win for
colliding names:

```ts
// src/app/app.config.ts
import { ApplicationConfig } from "@angular/core";
import { provideKxDefaultIcons, provideKxIcons } from "@dellik95/kadex-ui/icons";

export const appConfig: ApplicationConfig = {
  providers: [
    provideKxDefaultIcons(),
    provideKxIcons({ "brand-logo": "M12 2 2 7l10 5 10-5-10-5Z" }),
  ],
};
```

## Next

- **Theming** — dark mode via `ThemeService`, the token reference, and Tailwind (Option&nbsp;A)
  vs prebuilt (Option&nbsp;B) delivery.
- Browse the **Atoms** to start assembling a screen.
