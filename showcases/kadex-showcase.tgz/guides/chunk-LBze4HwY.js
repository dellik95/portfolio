import{_ as pi}from"./chunk-DauwpLFJ.js";import{bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var p={title:`Molecules/Hero Banner`,component:pi,argTypes:{title:{control:`text`},subtitle:{control:`text`},icon:{control:`text`},image:{control:`text`},avatarColor:{control:`inline-radio`,options:[`default`,`primary`,`secondary`,`success`,`info`,`warning`,`danger`]}},args:{title:`Senior Frontend Engineer`,subtitle:`Engineering · Remote (EU)`,icon:`briefcase`,image:null,avatarColor:`primary`},render:e=>({props:e,template:`<kx-hero-banner ${o(e)} />`})};var i={};var s={render:e=>({props:e,template:`
      <kx-hero-banner ${o(e)}>
        <span meta style="opacity:.7">Posted 3 days ago</span>
        <span badges style="display:inline-flex; gap:.5rem">
          <span style="padding:.125rem .5rem; border-radius:9999px; background:var(--kx-color-primary-soft, #e0e7ff); font-size:.75rem">Open</span>
        </span>
        <span actions style="display:inline-flex; gap:.5rem">
          <button style="padding:.5rem 1rem; border-radius:.375rem; border:1px solid var(--kx-color-border, #d1d5db)">Edit</button>
        </span>
      </kx-hero-banner>
    `})};export{i as Playground,s as WithProjectedContent,p as default};