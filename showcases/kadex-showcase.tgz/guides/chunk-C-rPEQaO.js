import{l as dt,o as be,t as Ce,x as ve}from"./chunk-DCAN7EnP.js";import"./chunk-DauwpLFJ.js";import{bt as o,yt as a}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var m={title:`Organisms/Entity Card`,component:dt,decorators:[a({imports:[ve,Ce,be]})],argTypes:{title:{control:`text`},subtitle:{control:`text`},loading:{control:`boolean`},canEdit:{control:`boolean`},startInEditMode:{control:`boolean`},scrollBody:{control:`boolean`},readOnly:{control:`boolean`}},args:{title:`Ada Lovelace`,subtitle:`Senior Frontend Engineer`,loading:!1,canEdit:!0,startInEditMode:!1,scrollBody:!1,readOnly:!1},render:t=>({props:t,template:`
      <div style="max-width:40rem; height:24rem">
        <kx-entity-card ${o(t)}>
          <button *kxCardActionsTemplate style="padding:.25rem .75rem; border-radius:.375rem; border:1px solid var(--kx-color-border, #d1d5db)">Edit</button>
          <div *kxCardView>
            <p style="margin:0 0 .5rem"><strong>Email:</strong> ada@example.com</p>
            <p style="margin:0 0 .5rem"><strong>Location:</strong> London, UK</p>
            <p style="margin:0"><strong>Experience:</strong> 8 years</p>
          </div>
          <div *kxCardEdit>
            <label style="display:block; margin-bottom:.5rem">
              Email
              <input value="ada@example.com" style="display:block; width:100%; padding:.5rem; border:1px solid var(--kx-color-border, #d1d5db); border-radius:.375rem" />
            </label>
          </div>
        </kx-entity-card>
      </div>
    `})};var p={};var c={args:{startInEditMode:!0}};var y={args:{loading:!0}};export{c as EditMode,y as Loading,p as Playground,m as default};