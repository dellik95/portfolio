import{a as k,i as f,o as p$1,s as x}from"./chunk-BSxDV0VB.js";import{yt as a}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var g={title:`Dialog/Dialog Container`,component:k,decorators:[a({imports:[x,f,p$1]})],argTypes:{loading:{control:`boolean`},variant:{control:`inline-radio`,options:[`default`,`confirmation`,`danger`,`fullscreen`]},titleId:{table:{disable:!0}},descriptionId:{table:{disable:!0}}},args:{loading:!1,variant:`default`},render:i=>({props:i,template:`
      <div style="width:min(100%, 440px)">
        <kx-dialog-container [loading]="loading" [variant]="variant" titleId="demo-title">
          <ng-template kxDialogHeader>
            <div style="padding:1rem 1.5rem; border-bottom:1px solid var(--kx-color-border, #e5e7eb)">
              <h2 id="demo-title" style="margin:0; font-size:1.125rem; font-weight:600">Archive vacancy?</h2>
            </div>
          </ng-template>
          <ng-template kxDialogContent>
            <p style="margin:0">
              This moves the vacancy to the archive. You can restore it later from the archived list.
            </p>
          </ng-template>
          <ng-template kxDialogActions>
            <button style="padding:.5rem 1rem; border-radius:.375rem; border:1px solid var(--kx-color-border, #d1d5db)">
              Cancel
            </button>
            <button style="padding:.5rem 1rem; border-radius:.375rem; border:0; background:var(--kx-color-primary, #4f46e5); color:#fff">
              Archive
            </button>
          </ng-template>
        </kx-dialog-container>
      </div>
    `})};var m={};var s={args:{loading:!0}};var p={args:{variant:`danger`}};export{p as Danger,s as Loading,m as Playground,g as default};