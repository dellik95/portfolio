import{s as _i}from"./chunk-DauwpLFJ.js";import{bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var r={title:`Molecules/Offcanvas`,component:_i,argTypes:{open:{control:`boolean`},position:{control:`inline-radio`,options:[`left`,`right`,`top`,`bottom`]},width:{control:`text`},title:{control:`text`},backdrop:{control:`boolean`},closeOnBackdrop:{control:`boolean`},closeOnEscape:{control:`boolean`},scrollableBody:{control:`boolean`}},args:{open:!0,position:`right`,width:`360px`,title:`Filters`,backdrop:!0,closeOnBackdrop:!0,closeOnEscape:!0,scrollableBody:!0},render:o$1=>({props:o$1,template:`
      <kx-offcanvas ${o(o$1)}>
        <p style="margin:0 0 1rem">Refine the candidate list.</p>
        <label style="display:block; margin-bottom:.5rem">
          <input type="checkbox" /> Available now
        </label>
        <label style="display:block">
          <input type="checkbox" /> Remote only
        </label>
      </kx-offcanvas>
    `})};var p={};var c={args:{position:`left`}};export{c as Left,p as Playground,r as default};