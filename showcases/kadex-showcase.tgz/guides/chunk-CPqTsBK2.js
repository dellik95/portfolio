import{p as kt}from"./chunk-DauwpLFJ.js";import{bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var i={title:`Molecules/Section`,component:kt,argTypes:{variant:{control:`inline-radio`,options:[`default`,`bordered`,`elevated`,`flat`]},padding:{control:`inline-radio`,options:[`none`,`sm`,`md`,`lg`]},position:{control:`inline-radio`,options:[`left`,`right`,`full`]},icon:{control:`text`},title:{control:`text`},description:{control:`text`},collapsible:{control:`boolean`},collapsed:{control:`boolean`},divider:{control:`boolean`},headerOnly:{control:`boolean`}},args:{variant:`bordered`,padding:`md`,position:`full`,icon:`user`,title:`Personal details`,description:`Contact information and basic profile.`,collapsible:!1,collapsed:!1,divider:!0,headerOnly:!1},render:o$1=>({props:o$1,template:`
      <div style="max-width:40rem">
        <kx-section ${o(o$1)}>
          <button sectionActions style="padding:.25rem .75rem; border-radius:.375rem; border:1px solid var(--kx-color-border, #d1d5db)">Edit</button>
          <p style="margin:0">Full name, email, and phone number are shown here.</p>
        </kx-section>
      </div>
    `})};var a={};var d={args:{collapsible:!0}};var s={args:{variant:`elevated`}};export{d as Collapsible,s as Elevated,a as Playground,i as default};