import{E as Sn,bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var n={title:`Atoms/Progress`,component:Sn,argTypes:{value:{control:{type:`range`,min:0,max:100}},max:{control:`number`},variant:{control:`inline-radio`,options:[`primary`,`success`,`warning`,`danger`]},striped:{control:`boolean`},animated:{control:`boolean`},showLabel:{control:`boolean`},height:{control:`text`}},args:{value:60,max:100,variant:`primary`,striped:!1,animated:!1,showLabel:!1,height:`8px`},render:r=>({props:r,template:`<kx-progress ${o(r)} />`})};var p={};var l={args:{showLabel:!0}};var i={args:{striped:!0,animated:!0}};var m={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-col gap-3">
        <kx-progress [value]="40" variant="primary" />
        <kx-progress [value]="60" variant="success" />
        <kx-progress [value]="80" variant="warning" />
        <kx-progress [value]="95" variant="danger" />
      </div>
    `})};export{p as Playground,i as Striped,m as Variants,l as WithLabel,n as default};