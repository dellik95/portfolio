import{n as B,r as M}from"./chunk-BSxDV0VB.js";import{yt as a}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var l={title:`Dialog/Confirmation Dialog`,component:B,decorators:[a({providers:[{provide:M,useValue:{close:()=>{}}}]})],args:{title:`Delete candidate?`,message:`This permanently removes the candidate and all associated notes. This cannot be undone.`,confirmText:`Delete`,cancelText:`Keep`,confirmColor:`warn`,icon:`delete`},argTypes:{confirmColor:{control:`inline-radio`,options:[`primary`,`accent`,`warn`]}},render:n=>({props:n,template:`
      <div style="width:min(100%, 420px)">
        <kx-confirmation-dialog
          [title]="title"
          [message]="message"
          [confirmText]="confirmText"
          [cancelText]="cancelText"
          [confirmColor]="confirmColor"
          [icon]="icon"
        />
      </div>`})};var m={};var s={args:{title:`Publish vacancy?`,message:`The vacancy becomes visible on the public career portal.`,confirmText:`Publish`,cancelText:`Cancel`,confirmColor:`primary`,icon:`info`}};export{s as Neutral,m as Playground,l as default};