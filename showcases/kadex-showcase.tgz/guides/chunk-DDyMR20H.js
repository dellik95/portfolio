import{c as z}from"./chunk-BSxDV0VB.js";import{bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var d={title:`Dialog/Form Dialog`,component:z,argTypes:{title:{control:`text`},submitLabel:{control:`text`},cancelLabel:{control:`text`},loading:{control:`boolean`}},args:{title:`Create candidate`,submitLabel:`Save`,cancelLabel:`Cancel`,loading:!1},render:e=>({props:e,template:`
      <div style="width:min(100%, 480px); border:1px solid var(--kx-color-border, #e5e7eb); border-radius:.5rem; overflow:hidden">
        <kx-form-dialog ${o(e)}>
          <div style="display:flex; flex-direction:column; gap:1rem">
            <label style="display:flex; flex-direction:column; gap:.35rem">
              <span style="font-size:.875rem">Full name</span>
              <input placeholder="Ada Lovelace" style="padding:.5rem .75rem; border:1px solid var(--kx-color-border, #d1d5db); border-radius:.375rem" />
            </label>
            <label style="display:flex; flex-direction:column; gap:.35rem">
              <span style="font-size:.875rem">Email</span>
              <input placeholder="ada@example.com" style="padding:.5rem .75rem; border:1px solid var(--kx-color-border, #d1d5db); border-radius:.375rem" />
            </label>
          </div>
        </kx-form-dialog>
      </div>
    `})};var i={};var n={args:{loading:!0}};export{n as Loading,i as Playground,d as default};