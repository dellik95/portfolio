import{b as ui}from"./chunk-DauwpLFJ.js";import{bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var n={title:`Molecules/Form Validation`,component:ui,argTypes:{label:{control:`text`},hint:{control:`text`},error:{control:`text`},required:{control:`boolean`},state:{control:`inline-radio`,options:[`idle`,`valid`,`invalid`,`pending`]}},args:{label:`Work email`,hint:`We only use this to send interview invites.`,error:null,required:!0,state:`idle`},render:t=>({props:t,template:`
      <div style="max-width:24rem">
        <kx-form-validation ${o(t)}>
          <input
            placeholder="you@company.com"
            style="width:100%; padding:.5rem .75rem; border:1px solid var(--kx-color-border, #d1d5db); border-radius:.375rem"
          />
        </kx-form-validation>
      </div>
    `})};var l={};var d={args:{state:`valid`}};var s={args:{state:`invalid`,error:`Enter a valid work email address.`}};var p={args:{state:`pending`,hint:`Checking availability...`}};export{s as Invalid,p as Pending,l as Playground,d as Valid,n as default};