import{y as si}from"./chunk-DauwpLFJ.js";import{bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import{Gr as m,Kr as n$1,Wr as l}from"./chunk-CtdGPoMJ.js";var n=[{id:1,title:`Sourcing`,body:`Find candidates across every channel.`},{id:2,title:`Screening`,body:`Rank applicants with AI scoring.`},{id:3,title:`Hiring`,body:`Move offers to signatures faster.`}];var c={title:`Molecules/Carousel`,component:si,argTypes:{autoPlay:{control:`boolean`},interval:{control:{type:`number`,min:1e3,step:500}},showDots:{control:`boolean`},showArrows:{control:`boolean`},loop:{control:`boolean`},items:{table:{disable:!0}},slides:{table:{disable:!0}}},args:{items:n,slides:n,autoPlay:!1,interval:3e3,showDots:!0,showArrows:!0,loop:!0},render:m$1=>{var t=m$1,{slides:i}=t,e=n$1(t,[`slides`]);return{props:m(l({},e),{slides:i}),template:`

        <kx-carousel ${o(e)}>
          <ng-template let-item>
            <div style="padding:2.5rem 2rem; text-align:center">
              <h3 style="margin:0 0 .5rem; font-weight:600">{{ item.title }}</h3>
              <p style="margin:0; opacity:.75">{{ item.body }}</p>
            </div>
          </ng-template>
        </kx-carousel>
    `}}};var d={};var g={args:{autoPlay:!0,interval:2e3}};export{g as Autoplay,d as Playground,c as default};