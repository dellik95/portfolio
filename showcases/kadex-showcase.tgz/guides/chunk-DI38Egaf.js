import{R as at,bt as o$1}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var o={title:`Atoms/Spinner`,component:at,argTypes:{size:{control:`inline-radio`,options:[`xs`,`sm`,`md`,`lg`,`xl`]},variant:{control:`inline-radio`,options:[`primary`,`secondary`,`white`]},label:{control:`text`}},args:{size:`md`,variant:`primary`,label:`Loading`},render:e=>({props:e,template:`<kx-spinner ${o$1(e)} />`})};var a={};var p={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex items-center gap-4">
        <kx-spinner size="xs" />
        <kx-spinner size="sm" />
        <kx-spinner size="md" />
        <kx-spinner size="lg" />
        <kx-spinner size="xl" />
      </div>
    `})};var l={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex items-center gap-4">
        <kx-spinner variant="primary" />
        <kx-spinner variant="secondary" />
        <span class="inline-flex rounded bg-slate-800 p-2"><kx-spinner variant="white" /></span>
      </div>
    `})};export{a as Playground,p as Sizes,l as Variants,o as default};