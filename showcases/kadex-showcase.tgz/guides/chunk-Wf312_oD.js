import{d as hi,h as mi}from"./chunk-DauwpLFJ.js";import{yt as a}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var n={title:`Molecules/Metadata Grid`,component:hi,decorators:[a({imports:[mi]})],render:()=>({template:`
      <kx-metadata-grid>
        <kx-metadata-card icon="mail" label="Email" value="ada@example.com" />
        <kx-metadata-card icon="phone" label="Phone" value="+44 20 7946 0958" />
        <kx-metadata-card icon="briefcase" label="Role" value="Senior Engineer" />
        <kx-metadata-card icon="calendar" label="Joined" value="Mar 2021" />
      </kx-metadata-grid>
    `})};var l={};export{l as Playground,n as default};