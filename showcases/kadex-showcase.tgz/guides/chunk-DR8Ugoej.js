import{bt as o,w as Pn}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var l={title:`Atoms/Rating`,component:Pn,argTypes:{value:{control:{type:`range`,min:0,max:5,step:1}},max:{control:`number`},size:{control:`inline-radio`,options:[`sm`,`md`,`lg`]},readonly:{control:`boolean`},color:{control:`color`}},args:{value:3,max:5,size:`md`,readonly:!1,color:`#FFB800`},render:o$1=>({props:o$1,template:`<kx-rating ${o(o$1)} />`})};var i={};var s={args:{readonly:!0,value:4}};var m={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-col gap-2">
        <kx-rating [value]="3" size="sm" />
        <kx-rating [value]="3" size="md" />
        <kx-rating [value]="3" size="lg" />
      </div>
    `})};export{i as Playground,s as Readonly,m as Sizes,l as default};