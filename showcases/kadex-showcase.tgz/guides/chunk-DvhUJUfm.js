import{P as Yt,bt as o,rt as we,yt as a}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var s={title:`Atoms/Card`,component:Yt,argTypes:{variant:{control:`inline-radio`,options:[`default`,`outlined`,`elevated`]},padding:{control:`inline-radio`,options:[`none`,`sm`,`md`,`lg`]},hoverable:{control:`boolean`},clickable:{control:`boolean`}},args:{variant:`default`,padding:`md`,hoverable:!1,clickable:!1},render:t=>({props:t,template:`
      <kx-card ${o(t)} style="width:min(100%, 22rem)">
        <p class="text-sm text-default">
          Cards group related content and actions on a single surface. This text is projected
          into the default content slot.
        </p>
      </kx-card>
    `})};var i={};var p={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap gap-4">
        <kx-card variant="default" style="width:min(100%, 14rem)"><p class="text-sm text-default">Default</p></kx-card>
        <kx-card variant="outlined" style="width:min(100%, 14rem)"><p class="text-sm text-default">Outlined</p></kx-card>
        <kx-card variant="elevated" style="width:min(100%, 14rem)"><p class="text-sm text-default">Elevated</p></kx-card>
      </div>
    `})};var c={decorators:[a({imports:[we]})],render:t=>({props:t,template:`
      <kx-card ${o(t)} style="width:min(100%, 22rem)">
        <div header class="font-semibold">Card title</div>
        <p class="text-sm text-default">
          The header and footer slots accept arbitrary projected content.
        </p>
        <div footer class="flex justify-end">
          <kx-button size="sm" variant="primary">Action</kx-button>
        </div>
      </kx-card>
    `})};export{i as Playground,p as Variants,c as WithHeaderAndFooter,s as default};