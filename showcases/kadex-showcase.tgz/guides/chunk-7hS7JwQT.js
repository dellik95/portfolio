import{bt as o,rt as we}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import{Gr as m$1,Kr as n,Wr as l}from"./chunk-CtdGPoMJ.js";var d={title:`Atoms/Button`,component:we,argTypes:{variant:{control:`select`,options:[`primary`,`secondary`,`success`,`warning`,`danger`,`ghost`,`outline`,`icon`,`text`,`ai`]},size:{control:`inline-radio`,options:[`sm`,`md`,`lg`,`xl`]},type:{control:`inline-radio`,options:[`button`,`submit`,`reset`]},iconPosition:{control:`inline-radio`,options:[`left`,`right`]},disabled:{control:`boolean`},loading:{control:`boolean`},fullWidth:{control:`boolean`},content:{control:`text`,description:`Projected label content`},icon:{table:{disable:!0}},clicked:{table:{disable:!0}}},args:{variant:`primary`,size:`md`,type:`button`,disabled:!1,loading:!1,fullWidth:!1,iconPosition:`left`,content:`Button`},render:u=>{var o$1=u,{content:s}=o$1,t=n(o$1,[`content`]);return{props:m$1(l({},t),{content:s}),template:`<kx-button ${o(t)}>{{ content }}</kx-button>`}}};var x={};var p={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap items-center gap-3">
        <kx-button variant="primary">Primary</kx-button>
        <kx-button variant="secondary">Secondary</kx-button>
        <kx-button variant="success">Success</kx-button>
        <kx-button variant="warning">Warning</kx-button>
        <kx-button variant="danger">Danger</kx-button>
        <kx-button variant="ghost">Ghost</kx-button>
        <kx-button variant="outline">Outline</kx-button>
        <kx-button variant="text">Text</kx-button>
        <kx-button variant="ai">AI</kx-button>
      </div>
    `})};var g={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap items-center gap-3">
        <kx-button size="sm">Small</kx-button>
        <kx-button size="md">Medium</kx-button>
        <kx-button size="lg">Large</kx-button>
        <kx-button size="xl">Extra large</kx-button>
      </div>
    `})};var m={args:{loading:!0,content:`Saving…`}};var k={args:{disabled:!0,content:`Disabled`}};var y={args:{fullWidth:!0,content:`Full width`},parameters:{layout:`padded`}};export{k as Disabled,y as FullWidth,m as Loading,x as Playground,g as Sizes,p as Variants,d as default};