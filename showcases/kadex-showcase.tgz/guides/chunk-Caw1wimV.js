import{_ as pt,b as ut,f as he,h as me}from"./chunk-DCAN7EnP.js";import"./chunk-DauwpLFJ.js";import{bt as o,yt as a}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var p={title:`Organisms/Menu`,component:me,decorators:[a({imports:[pt,he,ut]})],argTypes:{placement:{control:`inline-radio`,options:[`bottom-start`,`bottom-end`,`top-start`,`top-end`]},width:{control:`text`},closeOnSelect:{control:`boolean`},emptyStateLabel:{control:`text`}},args:{placement:`bottom-start`,width:`220px`,closeOnSelect:!0},render:e=>({props:e,template:`
      <div style="padding:4rem; display:flex; justify-content:center">
        <button
          [kxMenuTriggerFor]="menu"
          style="padding:.5rem 1rem; border-radius:.375rem; border:1px solid var(--kx-color-border, #d1d5db)"
        >
          Open menu
        </button>
        <kx-menu #menu ${o(e)}>
          <kx-menu-item value="edit" label="Edit" icon="edit" />
          <kx-menu-item value="duplicate" label="Duplicate" icon="copy" />
          <kx-menu-item value="share" label="Share" icon="share" shortcut="\u2318S" />
          <kx-menu-divider />
          <kx-menu-item value="delete" label="Delete" icon="trash" [danger]="true" />
        </kx-menu>
      </div>
    `})};var u={};var c={args:{placement:`bottom-end`}};export{c as BottomEnd,u as Playground,p as default};