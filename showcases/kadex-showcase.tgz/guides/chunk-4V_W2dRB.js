import{bt as o,p as Ie}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import{Gr as m$1,Kr as n,Wr as l}from"./chunk-CtdGPoMJ.js";var x={title:`Atoms/Chip`,component:Ie,argTypes:{appearance:{control:`inline-radio`,options:[`badge`,`tag`]},variant:{control:`select`,options:[`default`,`primary`,`success`,`warning`,`danger`,`info`,`muted`]},size:{control:`inline-radio`,options:[`sm`,`md`,`lg`]},shape:{control:`inline-radio`,options:[`pill`,`square`]},bordered:{control:`boolean`},dot:{control:`boolean`},removable:{control:`boolean`},content:{control:`text`,description:`Projected chip label`},removed:{table:{disable:!0}}},args:{appearance:`badge`,variant:`default`,size:`md`,shape:`pill`,bordered:!0,dot:!1,removable:!1,content:`Chip`},render:s=>{var t=s,{content:p}=t,e=n(t,[`content`]);return{props:m$1(l({},e),{content:p}),template:`<kx-chip ${o(e)}>{{ content }}</kx-chip>`}}};var m={};var h={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap items-center gap-2">
        <kx-chip variant="default">Default</kx-chip>
        <kx-chip variant="primary">Primary</kx-chip>
        <kx-chip variant="success">Success</kx-chip>
        <kx-chip variant="warning">Warning</kx-chip>
        <kx-chip variant="danger">Danger</kx-chip>
        <kx-chip variant="info">Info</kx-chip>
        <kx-chip variant="muted">Muted</kx-chip>
      </div>
    `})};var g={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap items-center gap-2">
        <kx-chip size="sm">Small</kx-chip>
        <kx-chip size="md">Medium</kx-chip>
        <kx-chip size="lg">Large</kx-chip>
      </div>
    `})};var k={args:{removable:!0,content:`Filter: Active`}};var u={args:{dot:!0,content:`Live`}};export{m as Playground,k as Removable,g as Sizes,h as Variants,u as WithDot,x as default};