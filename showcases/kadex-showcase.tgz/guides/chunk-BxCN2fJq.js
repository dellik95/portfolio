import{t}from"./chunk-CCIBSH2C.js";import{A as Vn,bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var c={title:`Atoms/Switch`,component:Vn,argTypes:{checked:{control:`boolean`},disabled:{control:`boolean`},size:{control:`inline-radio`,options:[`sm`,`md`,`lg`]},label:{control:`text`},labelPosition:{control:`inline-radio`,options:[`left`,`right`]},checkedChange:{table:{disable:!0}}},args:{checked:!1,disabled:!1,size:`md`,label:`Enable notifications`,labelPosition:`right`},render:e=>({props:e,template:`<kx-switch ${o(e)} />`})};var n={};var d={args:{checked:!0}};var p={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex items-center gap-6">
        <kx-switch size="sm" [checked]="true" label="Small" />
        <kx-switch size="md" [checked]="true" label="Medium" />
        <kx-switch size="lg" [checked]="true" label="Large" />
      </div>
    `})};var m={args:{disabled:!0,checked:!0,label:`Locked on`},parameters:t};export{d as Checked,m as Disabled,n as Playground,p as Sizes,c as default};