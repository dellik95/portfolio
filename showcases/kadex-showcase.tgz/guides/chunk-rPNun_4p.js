import{G as hn,bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var a={title:`Atoms/Divider`,component:hn,argTypes:{orientation:{control:`inline-radio`,options:[`horizontal`,`vertical`]},variant:{control:`inline-radio`,options:[`solid`,`dashed`,`dotted`]},spacing:{control:`inline-radio`,options:[`none`,`sm`,`md`,`lg`]},color:{control:`text`}},args:{orientation:`horizontal`,variant:`solid`,spacing:`md`,color:`border-subtle`},render:t=>({props:t,template:`<kx-divider ${o(t)} />`})};var d={};var l={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-col gap-2">
        <kx-divider variant="solid" />
        <kx-divider variant="dashed" />
        <kx-divider variant="dotted" />
      </div>
    `})};var p={args:{orientation:`vertical`},render:t=>({props:t,template:`<div class="flex h-16 items-center gap-2">Left<kx-divider ${o(t)} />Right</div>`})};export{d as Playground,l as Variants,p as Vertical,a as default};