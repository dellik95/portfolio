import{K as jt,bt as o$1}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var o=`data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='80'><rect width='80' height='80' fill='%234f46e5'/><text x='50%25' y='56%25' font-size='30' fill='white' text-anchor='middle' font-family='sans-serif'>JD</text></svg>`;var l={title:`Atoms/Avatar`,component:jt,argTypes:{name:{control:`text`},image:{control:`text`},icon:{control:`text`},alt:{control:`text`},size:{control:`inline-radio`,options:[`xs`,`sm`,`md`,`lg`,`xl`,`xxl`]},shape:{control:`inline-radio`,options:[`circle`,`rounded`,`square`]},color:{control:`select`,options:[`default`,`primary`,`secondary`,`success`,`info`,`warning`,`danger`]},bordered:{control:`boolean`}},args:{name:`Jane Doe`,size:`md`,shape:`circle`,color:`primary`,bordered:!1},render:a=>({props:a,template:`<kx-avatar ${o$1(a)} />`})};var i={};var m={args:{image:o,name:`Jane Doe`}};var c={args:{icon:`briefcase`,color:`primary`,shape:`rounded`}};var p={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex items-center gap-4">
        <kx-avatar name="Jane Doe" shape="circle" color="primary" />
        <kx-avatar name="Jane Doe" shape="rounded" color="primary" />
        <kx-avatar name="Jane Doe" shape="square" color="primary" />
      </div>
    `})};var x={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap items-center gap-3">
        <kx-avatar name="A B" color="default" />
        <kx-avatar name="A B" color="primary" />
        <kx-avatar name="A B" color="secondary" />
        <kx-avatar name="A B" color="success" />
        <kx-avatar name="A B" color="info" />
        <kx-avatar name="A B" color="warning" />
        <kx-avatar name="A B" color="danger" />
      </div>
    `})};var d={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap items-center gap-3">
        <kx-avatar name="A B" size="xs" color="primary" />
        <kx-avatar name="A B" size="sm" color="primary" />
        <kx-avatar name="A B" size="md" color="primary" />
        <kx-avatar name="A B" size="lg" color="primary" />
        <kx-avatar name="A B" size="xl" color="primary" />
        <kx-avatar name="A B" size="xxl" color="primary" />
      </div>
    `})};export{x as Colors,c as Icon,m as Image,i as Initials,p as Shapes,d as Sizes,l as default};