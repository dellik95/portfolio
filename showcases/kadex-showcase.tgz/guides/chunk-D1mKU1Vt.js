import{d as gt}from"./chunk-DCAN7EnP.js";import"./chunk-DauwpLFJ.js";import{bt as o}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import"./chunk-CtdGPoMJ.js";var d={title:`Organisms/Page`,component:gt,argTypes:{title:{control:`text`},subtitle:{control:`text`},backgroundGradient:{control:`boolean`},variant:{control:`inline-radio`,options:[`default`,`compact`]}},args:{title:`Vacancies`,subtitle:`Manage open roles and track applicants`,backgroundGradient:!0,variant:`default`},render:t=>({props:t,template:`
      <kx-page ${o(t)}>
        <button headerActions style="padding:.5rem 1rem; border-radius:.375rem; border:1px solid var(--kx-color-border, #d1d5db)">New vacancy</button>
        <div filterBar style="padding:.75rem 0; opacity:.75">Filters go here</div>
        <div style="padding:1.5rem 0">
          <p style="margin:0">Main page content \u2014 lists, tables, and forms render here.</p>
        </div>
        <span footer style="color:var(--color-text-muted)">\xA9 2026 Kadex UI</span>
      </kx-page>
    `})};var i={};var p={args:{variant:`compact`,backgroundGradient:!1}};export{p as Compact,i as Playground,d as default};