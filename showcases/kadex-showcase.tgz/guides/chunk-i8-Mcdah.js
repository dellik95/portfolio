import{bt as o,d as Fn}from"./main-5T27SPP5.js";import"./chunk-CCbKwm62.js";import{Gr as m$1,Kr as n,Wr as l}from"./chunk-CtdGPoMJ.js";var m={title:`Atoms/Tag`,component:Fn,argTypes:{content:{control:`text`},size:{control:`inline-radio`,options:[`sm`,`md`]},shape:{control:`inline-radio`,options:[`pill`,`square`]},variant:{control:`inline-radio`,options:[`primary`,`muted`,`success`,`warning`]},bordered:{control:`boolean`}},args:{content:`TypeScript`,size:`md`,shape:`pill`,variant:`primary`,bordered:!0},render:g=>{var r=g,{content:s}=r,t=n(r,[`content`]);return{props:m$1(l({},t),{content:s}),template:`<kx-tag ${o(t)}>{{ content }}</kx-tag>`}}};var d={};var x={parameters:{controls:{disable:!0}},render:()=>({template:`
      <div class="flex flex-wrap gap-2">
        <kx-tag variant="primary">Primary</kx-tag>
        <kx-tag variant="muted">Muted</kx-tag>
        <kx-tag variant="success">Success</kx-tag>
        <kx-tag variant="warning">Warning</kx-tag>
      </div>
    `})};export{d as Playground,x as Variants,m as default};