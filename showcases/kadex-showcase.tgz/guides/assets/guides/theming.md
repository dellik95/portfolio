# Theming

Every visual value in the design system — colors, spacing, radii, typography — is a **design
token** from `@dellik95/kadex-ui/tokens`. Components never hard-code these; they read the tokens,
so a single token layer themes the whole system and light/dark comes for free.

## Try it here

Use the **Theme** control in the top toolbar to flip This documentation site between **Light** and
**Dark**. Every story re-renders through the same runtime path an app uses: the selection drives
`ThemeService`, which reflects `data-theme` onto the document element and the tokens flip.

## Delivering the tokens in an app

There are two delivery modes — pick **one**, never both.

**Option&nbsp;B — prebuilt (no Tailwind).** Import the fully-materialized stylesheet. Every token,
keyframe, and utility the design system uses is already in it:

```css
/* src/styles.css */
@import "@dellik95/kadex-ui/tokens/prebuilt/kadex.css";
```

No build step. It does **not** generate Tailwind utilities for your _own_ markup.

**Option&nbsp;A — run Tailwind yourself.** If you already use Tailwind&nbsp;v4, consume the token
SCSS/CSS and add the design system as a `@source` so your own utilities are generated too. See
the token package README for the exact `@source` setup.

The tokens set `--font-sans` to Quicksand but do not bundle the font; load it (e.g. from Google
Fonts) or override `--font-sans` for your own typeface.

## Dark mode via ThemeService

`ThemeService` (from `@dellik95/kadex-ui/core`, root-provided) writes `data-theme` onto the document
element and persists the choice:

```ts
import { Component, inject } from "@angular/core";
import { ThemeService } from "@dellik95/kadex-ui/core";

@Component({
  selector: "app-theme-toggle",
  standalone: true,
  template: `
    <button (click)="theme.toggle()">Toggle theme</button>
  `,
})
export class ThemeToggleComponent {
  protected readonly theme = inject(ThemeService);
}
```

`theme.setMode("light" | "dark" | "auto")` sets an explicit mode; `"auto"` follows the OS
`prefers-color-scheme`.

## Reference

- The token package ships a full **TOKENS** reference listing the light and dark value of every
  token, plus how to override tokens and add an app palette.
- The prebuilt **`kx-theme-toggle`** molecule wraps `ThemeService` if you want a ready-made
  switch — see its story under **Molecules**.

## Project palettes

Choose **Forest palette** in the toolbar to preview the components with host-defined tokens. A consumer can register its own palette and switch it independently of the light, dark, Ember, or system color mode.

```ts
import { provideThemeService, ThemeService } from "@dellik95/kadex-ui/core";

// Application providers
provideThemeService({ brands: ["forest"] });

// Inside a component with theme = inject(ThemeService)
this.theme.setBrand("forest");
```

```css
:root[data-brand="forest"] {
  --color-primary: #147250;
  --chart-color-primary: #147250;
  --radius: 0.65rem;
  --font-sans: system-ui, sans-serif;
}
```
