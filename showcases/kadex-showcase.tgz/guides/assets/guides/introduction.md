# Kadex UI Design System

The Kadex UI design system is a set of standalone Angular&nbsp;22 components, a foundation
library, and a design-token layer — published publicly to GitHub Packages under the
`@dellik95` scope and consumed by the Qandivo application.

This documentation site is the living showcase: every component rendered in isolation, with editable
controls, theme previews, and input and output reference tables. Use it to see what exists, how a
component behaves, and how to wire it into an app.

## How the library is organized

Components follow atomic design and are shipped behind **secondary entry points**, so an app
imports only the layer it needs:

| Entry point                     | Layer      | Contains                                        |
| ------------------------------- | ---------- | ----------------------------------------------- |
| `@dellik95/kadex-ui/atoms`      | Atoms      | buttons, inputs, badges, and other primitives   |
| `@dellik95/kadex-ui/molecules`  | Molecules  | composed controls (cards, steppers, banners…)   |
| `@dellik95/kadex-ui/organisms`  | Organisms  | page-level blocks (entity cards, feeds, grids…) |
| `@dellik95/kadex-ui/navigation` | Navigation | breadcrumb, sidebar, sidebar link               |
| `@dellik95/kadex-ui/dialog`     | Dialog     | dialog / overlay components                     |
| `@dellik95/kadex-ui/icons`      | Icons      | `kx-icon`, the icon registry, `provideKxIcons`  |

Two heavier capabilities live in their own secondary entry points so apps that don't use
them pay nothing:

| Entry point                 | Contains                                    |
| --------------------------- | ------------------------------------------- |
| `@dellik95/kadex-ui/charts` | `kx-chart` and the chart theming service    |
| `@dellik95/kadex-ui/editor` | `kx-rich-text-editor` and HTML sanitization |

Everything rests on two foundation packages:

- **`@dellik95/kadex-ui/core`** — shared types, utilities, directives, and the `ThemeService`.
- **`@dellik95/kadex-ui/tokens`** — CSS/SCSS design tokens (colors, spacing, typography) with a
  prebuilt, zero-build stylesheet.

The sidebar mirrors this layering: **Atoms → Molecules → Organisms → Navigation → Dialog →
Icons → Charts → Editor**.

## Finding your way around a component

Each component has a **Docs** page and one or more **stories**:

- **Docs** — an overview, the inputs/outputs reference, and every story rendered inline.
- **Canvas** — a single story with the **Controls** panel: change inputs live and watch the
  component react. Use **Show code** to copy the exact template.
- **Theme** toolbar (top toolbar) — flip the whole preview between light and dark to check
  contrast and token behavior.
- **Accessibility** panel — an axe scan of the rendered story, reported inline.

## Next

- **Getting Started** — point npm at the registry, install, load the styles, render a
  component.
- **Theming** — light/dark, the token layer, and the two ways to deliver the styles.
